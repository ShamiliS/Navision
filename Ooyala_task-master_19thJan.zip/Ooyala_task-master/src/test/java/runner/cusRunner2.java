package test.java.runner;

import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;

import cucumber.api.java.Before;

public class cusRunner2 {
	public static String type; 
	
	/*@Before
	public static String getBrowserType(){
		return type = customRunner.strListBrowsers.get(0);
	}*/
	
}
