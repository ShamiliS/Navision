package test.java.runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features = "feature", glue = { "test.java.Ooyala" })
public class TestRun extends AbstractTestNGCucumberTests {

}